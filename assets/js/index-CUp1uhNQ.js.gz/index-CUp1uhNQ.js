import{d as e,o as a,c as n}from"./@vue-pvvZVrFb.js";const r=e({name:"BaseTable",__name:"index",setup(t){return(o,s)=>(a(),n("div",null,"base_table"))}});export{r as default};
